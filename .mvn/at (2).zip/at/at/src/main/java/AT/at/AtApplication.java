package AT.at;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtApplication.class, args);
	}

}
